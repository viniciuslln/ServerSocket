g++ -std=c++11 *.hpp *.h *.cpp -o cli -lpthread
